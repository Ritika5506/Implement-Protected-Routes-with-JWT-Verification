
const bcrypt = require('bcrypt');
// Seed users (in-memory). Passwords are hashed synchronously for demo purposes.
// DO NOT use synchronous hashing in production startup for many users.

const users = [
  {
    id: 1,
    username: 'admin',
    role: 'admin',
    // password: adminpass
    passwordHash: bcrypt.hashSync('adminpass', 10)
  },
  {
    id: 2,
    username: 'mod',
    role: 'moderator',
    // password: modpass
    passwordHash: bcrypt.hashSync('modpass', 10)
  },
  {
    id: 3,
    username: 'alice',
    role: 'user',
    // password: alicepass
    passwordHash: bcrypt.hashSync('alicepass', 10)
  }
];

module.exports = { users };
