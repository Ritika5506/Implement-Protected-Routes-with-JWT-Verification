
# RBAC Express JWT Example

This project demonstrates Role-Based Access Control (RBAC) using Node.js, Express and JWTs.
There are three roles: **admin**, **moderator**, and **user**.

## Quick start

1. Install dependencies
   ```bash
   npm install
   ```
2. Start server
   ```bash
   npm start
   ```
3. Login to get tokens (seed users below). Use curl or Postman.

## Seed users

The repository contains pre-seeded users (in-memory):

- admin / password: `adminpass` (role: admin)
- mod / password: `modpass` (role: moderator)
- alice / password: `alicepass` (role: user)

## Endpoints

- `POST /login` — body: `{ "username": "...", "password": "..." }` — returns `{ token }`
- `GET /admin/dashboard` — Admin only
- `GET /moderator/manage` — Moderator only (admin allowed too)
- `GET /user/profile` — Any authenticated user (admin/moderator/user)

## Example curl tests

1. Login as admin:
   ```bash
   curl -s -X POST http://localhost:3000/login -H "Content-Type: application/json" -d '{"username":"admin","password":"adminpass"}'
   ```
2. Use token to access admin dashboard:
   ```bash
   TOKEN=<paste token>
   curl -H "Authorization: Bearer $TOKEN" http://localhost:3000/admin/dashboard
   ```
3. Try with insufficient role (e.g., user trying admin route) — you'll get 403 Forbidden.

## Notes

- This example uses an in-memory user store for simplicity. For production, use a database.
- Store JWT secret in environment variables. For demo it's in code only.
