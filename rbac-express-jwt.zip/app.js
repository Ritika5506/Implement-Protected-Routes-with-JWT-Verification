
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { users } = require('./users');
const authRoutes = require('./routes/auth');
const { verifyToken, requireRole } = require('./middleware/auth');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Routes
app.use('/', authRoutes);

// Protected routes examples
app.get('/admin/dashboard', verifyToken, requireRole('admin'), (req, res) => {
  res.json({ message: `Welcome to admin dashboard, ${req.user.username}` });
});

// Moderator route (allow moderators and admins)
app.get('/moderator/manage', verifyToken, requireRole('moderator','admin'), (req, res) => {
  res.json({ message: `Moderator area. Hello ${req.user.username} (${req.user.role})` });
});

// General user profile route (any authenticated role)
app.get('/user/profile', verifyToken, requireRole('user','moderator','admin'), (req, res) => {
  // Return a simple profile demonstration
  const profile = {
    id: req.user.id,
    username: req.user.username,
    role: req.user.role,
    info: 'This is a demo profile endpoint.'
  };
  res.json(profile);
});

// Error handler for unknown routes
app.use((req,res)=>{
  res.status(404).json({ error: 'Not found' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log(`Server running on http://localhost:${PORT}`));
