
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'replace_this_with_a_secure_secret';

// Verify JWT and attach user to req.user
function verifyToken(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authorization header missing or malformed' });
  }
  const token = auth.split(' ')[1];
  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ error: 'Invalid or expired token' });
    }
    // decoded contains user's id, username, role
    req.user = decoded;
    next();
  });
}

// Role guard - accepts allowed roles as arguments
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user || !req.user.role) {
      return res.status(401).json({ error: 'No user authenticated' });
    }
    const role = req.user.role;
    // Normalize roles to lowercase for safety
    const normalized = role.toString().toLowerCase();
    const allowed = allowedRoles.map(r => r.toString().toLowerCase());
    if (!allowed.includes(normalized)) {
      return res.status(403).json({ error: 'Forbidden - insufficient role' });
    }
    next();
  };
}

module.exports = { verifyToken, requireRole };
