
const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');

dotenv.config();
const app = express();
app.use(bodyParser.json());

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'mysecretkey';

// Hardcoded sample user
const user = { username: 'testuser', password: 'testpass' };

// Login route - issues JWT if credentials are valid
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (username === user.username && password === user.password) {
    const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: '1h' });
    return res.json({ message: 'Login successful', token });
  }
  res.status(401).json({ error: 'Invalid credentials' });
});

// Middleware to verify JWT
function verifyToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or malformed Authorization header' });
  }
  const token = authHeader.split(' ')[1];
  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = decoded; // attach decoded token payload
    next();
  });
}

// Protected route example
app.get('/protected', verifyToken, (req, res) => {
  res.json({ message: `Welcome ${req.user.username}, you have accessed a protected route!` });
});

// Public route (no auth required)
app.get('/', (req, res) => {
  res.send('Public route - try POST /login then GET /protected with your token.');
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
