
# JWT Protected Routes Example

This example demonstrates how to protect routes in an Express.js app using JSON Web Tokens (JWT).

## Setup

1. Install dependencies
   ```bash
   npm install
   ```
2. Copy `.env.example` to `.env` and adjust values if needed.
3. Start the server
   ```bash
   npm start
   ```

## Routes

- `POST /login` — returns a JWT token when credentials are correct.
- `GET /protected` — requires a valid JWT token in the `Authorization` header.

## Example test

1. Login to get a token:
   ```bash
   curl -X POST http://localhost:3000/login -H "Content-Type: application/json" -d '{"username":"testuser","password":"testpass"}'
   ```

2. Copy the `token` from response and access protected route:
   ```bash
   curl -H "Authorization: Bearer <token>" http://localhost:3000/protected
   ```

3. Try accessing `/protected` without token:
   ```bash
   curl http://localhost:3000/protected
   ```
   → Should return 401 Unauthorized
